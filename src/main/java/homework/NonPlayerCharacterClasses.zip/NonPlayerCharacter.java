/**
 * NPC class.
 */
public class NonPlayerCharacter extends Character {

    private static final int GENERAL_START_HEALTH = 15;

    public NonPlayerCharacter(String name, String job) {
        super(name, job, GENERAL_START_HEALTH);
    }
}
